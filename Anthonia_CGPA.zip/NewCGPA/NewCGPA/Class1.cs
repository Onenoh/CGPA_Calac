﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCGPA
{
    internal class Data
    {
        public string S1 { get; set; }
        public int S2 { get; set; }
        public char S3 { get; set; }
        public int S4 { get; set; }
        public int S5 { get; set; }
        public string S6 { get; set; }
    }
}
